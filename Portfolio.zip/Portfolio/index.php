<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>My Portfolio</title>
  <meta content="" name="description">
  <meta content="" name="keywords">


  <link href="assets/img/icon.jpg" rel="icon">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  
  <link href="assets/css/style.css" rel="stylesheet">

</head>

<body>
  <a id="top"></a>


  <header id="header">
    <div class="container">

      <h1><a href="index.html">Zcyemarc Kiel Colendres</a></h1>
      <h2>I'm a Student <span>Front End Developer</span> from Cavite</h2>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link active" href="#header">Home</a></li>
          <li><a class="nav-link" href="#about">About</a></li>
          <li><a class="nav-link" href="#resume">Resume</a></li>
          <li><a class="nav-link" href="#portfolio">Portfolio</a></li>
          <li><a class="nav-link" href="#contact">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

      <div class="social-links">
        <a href="https://x.com/kielclndrs"  target="_blank"><i class="bi bi-twitter"></i></a>
        <a href="https://www.facebook.com/kiel.mapogs?mibextid=LQQJ4d" target="_blank"><i class="bi bi-facebook"></i></a>
        <a href="https://www.instagram.com/kiel_mistry?igsh=MWNzeGwybjh5ejJlaw%3D%3D&utm_source=qr" target="_blank"><i class="bi bi-instagram"></i></a>
      </div>

    </div>
  </header>

  <section id="about" class="about">

    <div class="about-me container">

      <div class="section-title">
        <h2>About</h2>
        <p>Learn more about me</p>
      </div>

      <div class="row">
        <div class="col-lg-4" data-aos="fade-right">
          <img src="assets/img/me.jpg" class="img-fluid" alt="">
        </div>
        <div class="col-lg-8 pt-4 pt-lg-0 content" data-aos="fade-left">
          <h3>Student &amp; Front End Developer</h3>
          <p class="fst-italic">
            The greatest pleasure in life is doing what people say you cannot do.
                      
          </p>
          <div class="row">
            <div class="col-lg-6">
              <ul>
                <li><i class="bi bi-chevron-right"></i> <strong>Birthday:</strong> <span>April 17, 2003</span></li>
                <li><i class="bi bi-chevron-right"></i> <strong>Phone:</strong> <span>+63 995 157 5337</span></li>
                <li><i class="bi bi-chevron-right"></i> <strong>City:</strong> <span>Dasma, Cavite</span></li>
              </ul>
            </div>
            <div class="col-lg-6">
              <ul>
                <li><i class="bi bi-chevron-right"></i> <strong>Age:</strong> <span>21</span></li>
                <li><i class="bi bi-chevron-right"></i> <strong>Degree:</strong> <span>Bachelor in Information Technology</span></li>
                <li><i class="bi bi-chevron-right"></i> <strong>Email:</strong> <span>kielcolendres@gmail.com</span></li>
              </ul>
            </div>
          </div>
          <p>
            I am currently studying at Cavite State University and graduating, I am specialize in front end developing field and have simple knowledge about Php programming, i also know MySql Database, Java, Html, and CSS.
          </p>
        </div>
      </div>

    </div>

        <div class="swiper-pagination"></div>
      </div>

      <div class="owl-carousel testimonials-carousel">

      </div>
  </section>

  <section id="resume" class="resume">
    <div class="container">

      <div class="section-title">
        <h2>Resume</h2>
        <p>Check My Resume</p>
      </div>

      <div class="row">
        <div class="col-lg-6">
          <h3 class="resume-title">Summary</h3>
          <div class="resume-item pb-0">
            <h4>Zcyemarc Kiel Colendres</h4>
            <p><em>A passionate and deadline-driven  Student Front End Developer currently learning some skills to improve developing skills.</em></p>
            <p>
            <ul>
              <li>Langkaan 1, Dasma Cavite</li>
              <li>+63 995 157 5337</li>
              <li>kielcolendres@gmail.com</li>
            </ul>
            </p>
          </div>

          <h3 class="resume-title">Education</h3>
          <div class="resume-item">
            <h4>Bachelor of Information Technology &amp; Computer Science</h4>
            <h5>2021 - 2024</h5>
            <p><em>Cavite State University Silang</em></p>
            <p>Graduated in Cavite State University with high honors and part of the Student Council.</p>
          </div>
        </div>
        <div class="col-lg-6">
          <h3 class="resume-title">Work Experience</h3>
          <div class="resume-item">
            <h4>Service Crew</h4>
            <h5>2022</h5>
            <p><em>Burol, Dasma </em></p>
            <p>
            <ul>
              <li>Taking orders from the costumers.</li>
              <li>Assembling the orders. </li>  
            </ul>
            </p>
          </div>

          <div class="col-lg-6">
          <h3 class="resume-title">Skills</h3>
          <div class="resume-item">
            <h4>Professional Skils</h4>
            <ul>
              <li>PHP Programming Language</li>
              <li>HTML Structure </li>  
              <li>CSS</li>
              <li>Java</li>
            </ul>
            </p>
          </div>


          </div>
        </div>
      </div>

    </div>
  </section><!-- End Resume Section -->

  

  <!-- ======= Portfolio Section ======= -->
  <section id="portfolio" class="portfolio">
    <div class="container">

      <div class="section-title">
        <h2>Portfolio</h2>
        <p>My Work</p>
      </div>

      <div class="row">
        <div class="col-lg-12 d-flex justify-content-center">
          <ul id="portfolio-flters">
            
            <li data-filter=".filter-app">App</li>
          </ul>
        </div>
      </div>

      <div class="row portfolio-container">

        <div class="col-lg-4 col-md-6 portfolio-item filter-app">
          <div class="portfolio-wrap">
            <img src="assets/img/portfolio/portfolio-6.png" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>App 3</h4>
              <p>App</p>
              <div class="portfolio-links">
                <a href="assets/img/portfolio/portfolio-6.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="App 3"><i class="bx bx-plus"></i></a>
                <a href="portfolio-details.html" data-gallery="portfolioDetailsGallery" data-glightbox="type: external" class="portfolio-details-lightbox" title="Portfolio Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>
        </div>

        

    </div>
  </section>

  <!-- ======= Contact Section ======= -->
  <section id="contact" class="contact">
    <div class="container">

      <div class="section-title">
        <h2>Contact</h2>
        <p>Contact Me</p>
      </div>

      <div class="row mt-2">

        <div class="col-md-6 d-flex align-items-stretch">
          <div class="info-box">
            <i class="bx bx-map"></i>
            <h3>My Address</h3>
            <p>Tierra Vista Ayana, Langkaan 1, Dasma Cavite</p>
          </div>
        </div>

        <div class="col-md-6 mt-4 mt-md-0 d-flex align-items-stretch">
          <div class="info-box">
            <i class="bx bx-share-alt"></i>
            <h3>Social Profiles</h3>
            <div class="social-links">
              <a href="https://x.com/kielclndrs" target="_blank" class="twitter"><i class="bi bi-twitter"></i></a>
              <a href="https://www.facebook.com/kiel.mapogs?mibextid=LQQJ4d" target="_blank" class="facebook"><i class="bi bi-facebook"></i></a>
              <a href="https://www.instagram.com/kiel_mistry?igsh=MWNzeGwybjh5ejJlaw%3D%3D&utm_source=qr" target="_blank" class="instagram"><i class="bi bi-instagram"></i></a>
            </div>
          </div>
        </div>

        <div class="col-md-6 mt-4 d-flex align-items-stretch">
          <div class="info-box">
            <i class="bx bx-envelope"></i>
            <h3>Email Me</h3>
            <p>kielcolendres@gmail.com</p>
          </div>
        </div>
        <div class="col-md-6 mt-4 d-flex align-items-stretch">
          <div class="info-box">
            <i class="bx bx-phone-call"></i>
            <h3>Call Me</h3>
            <p>+63 995 157 5337</p>
          </div>
        </div>
      </div>
      
      <form action="forms/contact.php" method="post" role="form" class="php-email-form mt-4">
        <div class="row">
          <div class="col-md-6 form-group">
            <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
          </div>
          <div class="col-md-6 form-group mt-3 mt-md-0">
            <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
          </div>
        </div>
        <div class="form-group mt-3">
          <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
        </div>
        <div class="form-group mt-3">
          <textarea class="form-control" name="message" rows="5" placeholder="Message" required></textarea>
        </div>
        <div class="my-3">
          <div class="loading">Loading</div>
          <div class="error-message"></div>
          <div class="sent-message">Your message has been sent. Thank you!</div>
        </div>
        <div class="text-center"><button type="submit">Send Message</button></div>
      </form>

    </div>
  </section><!-- End Contact Section -->

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <script src="assets/js/main.js"></script>
  <script>
     document.addEventListener('DOMContentLoaded', function () {
      // Scroll to the top
      document.getElementById('top').scrollIntoView({ behavior: 'smooth' });
    });
    </script>

</body>

</html>